package com.cg.payroll.main;

import com.cg.payroll.services.PayrollServicesImplementation;
public class MainClass {
	
	public static void main(String[] args) {
	PayrollServicesImplementation  payrollServices= new PayrollServicesImplementation();
		 
	int associateId =	payrollServices.acceptAssociateDetails("Dileep", "Godishala", "godishala@abc.com", "Training", "A4", "ASKHGD", 150000, 20000, 1000, 1000, 123456789, "hdfc", "hdfc007");
		System.out.println(associateId);
		System.out.println(payrollServices.getAssociateDetails(associateId).getFirstName());
		payrollServices.calculateNetSalary(associateId);
		System.out.println(payrollServices.getAssociateDetails(associateId).getSalary().getNetSalary());
		
	
	int associateId1 = payrollServices.acceptAssociateDetails("Dil", "Kum", "sdaf", "jhdf", "lfdg", "reowui", 15000, 25345, 1222, 1222, 12346, "ICICI", "ICICI005");
		System.out.println(associateId1);
		System.out.println(payrollServices.getAssociateDetails(associateId1).getFirstName());
		payrollServices.calculateNetSalary(associateId1);
		System.out.println(payrollServices.getAssociateDetails(associateId1).getSalary().getNetSalary());
	}
}
