package com.cg.payroll.main;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServicesImplementation;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImplementation;
public class MainArray {
	
		
		private PayrollServicesImplementation services;
		
		public MainArray() {
			services = new PayrollServicesImplementation();
		}
		
		
	public static void main(String[]str) {
		String firstName="Dileep";
		float basicSalary=35000;
		int yearlyInvestmentUnder80CToBeSearch=50000;
		
		Associate associate = searchAssociate(yearlyInvestmentUnder80CToBeSearch,firstName,basicSalary);
		if(associate!=null)
			System.out.println(associate.getFirstName()+" "+associate.getLastName()+" "+associate.getSalary().getBasicSalary());
		else
			System.out.println("associate details with Name" + firstName + "Not found");
	}
	public static Associate searchAssociate(int yearlyInvestmentUnder80CToBeSearch,String firstName,float basicSalary ){
		Associate[] associates = new Associate[4];
		 associates[0] = new Associate(123, 55346, "Dileep", "Godishala", "asd", "asdf", "thrw", "sdfrg",new Salary(36000, 2, 2, 3, 4, 3, 5, 4, 8, 50000, 40000),new BankDetails(123546, "StanChart", "SBIN0078"));
		 associates[1] = new Associate(456, 15654, "Dileep", "ADFV", "ASDFC", "BFGAD", "BGDS", "BADFVVB",new Salary(34000, 3, 4, 5, 6, 7, 8, 9, 8, 60000, 40000),new BankDetails(321456, "Hdfc", "ASdfg"));
		for(Associate associate:associates)
			if(associate.getFirstName()== firstName && associate.getYearlyInvestmentUnder80C()>=yearlyInvestmentUnder80CToBeSearch&&associate.getSalary().getBasicSalary()>=35000)
				return associate;
			else
				return null;
		return null;
	}
}
