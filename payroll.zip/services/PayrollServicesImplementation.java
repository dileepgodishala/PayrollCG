package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImplementation;
public class PayrollServicesImplementation{
	private PayrollDAOServicesImplementation daoServices;
	public PayrollServicesImplementation() {
		daoServices = new PayrollDAOServicesImplementation();
	}
	public int acceptAssociateDetails(String firstName, String lastName,
			String emailId,String department, String designation,String pancard, 
			int yearlyInvestmentUnder80C,double basicSalary, double epf, double companyPf,int accountNumber,	String bankName, String ifscCode) {
		
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}
	public double calculateNetSalary(int associateId) {
		Associate associate = this.getAssociateDetails(associateId);
		if(associate!=null) {
			double annualTax=0;
			
			double annualSalary=associate.getSalary().getGrossSalary()*12;
		    associate.getSalary().setPersonalAllowance(associate.getSalary().getBasicSalary()*0.3);
			associate.getSalary().setConveyenceAllowance(associate.getSalary().getBasicSalary()*0.2);
			associate.getSalary().setOtherAllowance(associate.getSalary().getBasicSalary()*0.1);
			associate.getSalary().setHra(associate.getSalary().getBasicSalary()*0.25);
			associate.getSalary().setGratuity(associate.getSalary().getBasicSalary()*0.05);
			associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getCompanyPf()+associate.getSalary().getHra());
			
		    
			if((associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getCompanyPf())+(12*associate.getSalary().getEpf())<=150000)) {
				if(annualSalary>=1000000) {
					annualTax=(annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getCompanyPf())-(12*associate.getSalary().getEpf()));
				}
				else if(annualSalary>=500000&&annualSalary<100000) 
					annualTax=(0.2f*(annualSalary-500000)+(0.1*100000)+(0.1f*(150000-(associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf())))));
				else if(annualSalary<500000 && annualSalary>=250000)
					if(annualSalary-250000>(associate.getYearlyInvestmentUnder80C()+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf()))
						annualTax=0.1f*(annualSalary-250000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getEpf()-12*associate.getSalary().getCompanyPf()));
					else 
						annualTax=0;
				else if(annualSalary<250000)
					annualTax=0;
			}
			else {
				if(annualSalary>=1000000) 
					annualTax=((annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000));
				else if(annualSalary>=500000&&annualSalary<100000)
					annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000));
				else if(annualSalary<500000 && annualSalary>=250000)
					annualTax=(0.1f*(100000));
				else
					annualTax=0;
			}
			associate.getSalary().setMonthlyTax(annualTax/12);
			associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
		
		return associate.getSalary().getNetSalary();
		}	
		return 0;
	}

	
	public Associate getAssociateDetails(int associateId) {
		return daoServices.getAssociate(associateId);
	}
	public Associate[] getAllAssociatesDetails() {
		return daoServices.getAssociates();
	}
}