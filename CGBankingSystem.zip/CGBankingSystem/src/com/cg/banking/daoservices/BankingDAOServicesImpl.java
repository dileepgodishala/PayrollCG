package com.cg.banking.daoservices;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
public class BankingDAOServicesImpl {
	private static Customer[] customer=new Customer[10];
	private static int CUSTOMER_ID_COUNTER=001;
	private static long ACCOUNT_NO_COUNTER=0;
	public long insertCustomer(Customer customer,Account account) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		account.setAccountNo(ACCOUNT_NO_COUNTER++);
		
		customerList[CUSTOMER_ID_IDX++]=customer;
		return customer.getCustomerId();
	}
	public boolean updateCustomer(Customer customer) {
		for(int i=0;i<customerList.length;i++) {
			if(customerList[i]!=null&&customer.getCustomerId()==customerList[i].getCustomerId()) {
				customerList[i]=customer;
			}
				return true;
		}
	return false;
	}
	
	
	
	
	
	
	
	
}
