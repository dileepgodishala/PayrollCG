package com.cg.banking.main;
public class MainClass {
	public static void main(String[] args) {
		
	}
}
