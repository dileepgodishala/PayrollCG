package com.cg.payroll.daoservices;
import com.cg.payroll.beans.Associate;
public class PayrollDAOServicesImplementation implements PayrollDAOServices {
	private static Associate[] associateList=new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=001;
	private static int ASSOCIATE_ID_IDX=0;
	@Override
	public int insertAssociate(Associate associate) {
		if(ASSOCIATE_ID_IDX>=0.7*associateList.length) {
			Associate[] ass=new Associate[associateList.length+10];
			System.arraycopy(associateList, 0, ass, 0, 15);
			associateList=ass;
		}
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_ID_IDX++]=associate;
		return associate.getAssociateID();
	}
	@Override
	public boolean updateAssociate(Associate associate){
		for(int i=0;i<associateList.length;i++) {
			if(associateList[i]!=null && associateList[i].getAssociateID()==associate.getAssociateID());
				associateList[i]=associate;
				return true;
		}
		return false;
	}
	@Override
	public boolean deleteAssociate(int associateId) {
		for(int i=0;i<associateList.length;i++) 
			if(associateList[i]!=null &&associateId==associateList[i].getAssociateID()) 
				associateList[i]=null;
				return true;
	}
	@Override
	public Associate getAssociate(int associateId){
		for(int i=0;i<associateList.length;i++) 
			if(associateList[i]!=null &&associateList[i].getAssociateID()==associateId)
				return associateList[i];
		return null;
	}
	@Override
	public Associate[] getAssociates(){
		return associateList;
	}
}
