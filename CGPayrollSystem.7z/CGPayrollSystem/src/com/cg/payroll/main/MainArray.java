package com.cg.payroll.main;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImplementation;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
public class MainArray {
	private PayrollServices services;
	public MainArray() {
		services = new PayrollServicesImplementation();
	}
	public static void main(String[]str) {
		String firstName="Dileep";
		float basicSalary=35000;
		int yearlyInvestmentUnder80CToBeSearch=50000;
		Associate associate = searchAssociate(yearlyInvestmentUnder80CToBeSearch,firstName,basicSalary);
		if(associate!=null)
			System.out.println(associate.getFirstName()+" "+associate.getLastName()+" "+associate.getSalary().getBasicSalary());
		else
			System.out.println("associate details with Name " + firstName +"and basic salary greater than "+basicSalary + " Not found");
	}
	public static Associate searchAssociate(int yearlyInvestmentUnder80CToBeSearch,String firstName,float basicSalary ){
		Associate[] associates = new Associate[4];
		associates[0]=new Associate(123, 50004, "Dileep", "Godishala", "Trainee", "A4", "ASDFGH45", "Godis@abc.com", new Salary(30000, 2, 3, 4, 5, 5000, 1000, 1000, 5, 50000, 45000),new BankDetails(12345, "Stanc", "STAN567"));
		associates[1]=new Associate(124, 60000, "Dileep", "Godi", "Training", "A6", "QWERTY", "Godish@abc",new Salary(36000, 5, 6, 4, 8, 1000, 1000, 1000, 6, 60000, 40000),new BankDetails(12345, "ICICI", "ASDF!@"));
		for(Associate associate:associates)
			if(associate.getFirstName()== firstName && associate.getYearlyInvestmentUnder80C()>=yearlyInvestmentUnder80CToBeSearch&&associate.getSalary().getBasicSalary()>=basicSalary)
				return associate;
			else
				return null;
		return null;
	}
}
