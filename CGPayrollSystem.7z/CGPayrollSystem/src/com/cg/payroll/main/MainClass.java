package com.cg.payroll.main;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImplementation;
public class MainClass {
	public static void main(String[] args) {
		PayrollServices  payrollServices= new PayrollServicesImplementation();
		int associateId=payrollServices.acceptAssociateDetails("Dileep", "Godishala", "godishala@abc.com", "Training", "A4", "ASKHGD", 150000, 50000, 1000, 1000, 123456789, "hdfc", "hdfc007");
		System.out.println(associateId);
		System.out.println(payrollServices.getAssociateDetails(associateId).getFirstName());
		payrollServices.calculateNetSalary(associateId);
		System.out.println(payrollServices.getAssociateDetails(associateId).getSalary().getNetSalary());
		System.out.println(payrollServices.getAssociateDetails(associateId).getSalary().getMonthlyTax());
		System.out.println();
	}
}
