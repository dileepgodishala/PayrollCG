package com.cg.payroll.services;
import com.cg.payroll.beans.Associate;
public interface PayrollServices {
	int acceptAssociateDetails(String firstName, String lastName, String emailId, String department, String designation,
			String pancard, int yearlyInvestmentUnder80C, double basicSalary, double epf, double companyPf,
			int accountNumber, String bankName, String ifscCode);
	double calculateNetSalary(int associateId);
	Associate getAssociateDetails(int associateId);
	Associate[] getAllAssociatesDetails();
}